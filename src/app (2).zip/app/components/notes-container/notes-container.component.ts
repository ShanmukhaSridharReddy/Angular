import { Component, OnInit } from '@angular/core';
import { error } from 'console';
import { NoteService } from 'src/app/services/note.service';

@Component({
  selector: 'app-notes-container',
  templateUrl: './notes-container.component.html',
  styleUrls: ['./notes-container.component.scss'],
  host:{
    class:"app-note-cnt"
  }
})
export class NotesContainerComponent implements OnInit {
  notesList:[]=[]
  toggleState:boolean=true;
  title:any ="";
  desc:any="";
  
  constructor(public noteService:NoteService) { }

  ngOnInit(): void {
   this.noteService.getAllNotes().subscribe(
    res => this.notesList=res.data,
   err=>console.log(err));
    
  }
  toggleCreateNote(){
    this.toggleState=!this.toggleState;

  }
  handleSaveNote(){
    this.toggleState=!this.toggleState;
    let noteObj={
      "title": this.title,
      "description": this.desc,
      "remainder": "2024-01-17T07:20:11.565Z",
      "colors": "",
      "image": "",
      "isArchive": true,
      "isPin": true,
      "isTrash": true
    }
    console.log(noteObj)
    this.noteService.createNotes(noteObj,Headers).subscribe(
      res => console.log(res),
     err=>console.log(err));
  }

}
