import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-trash-container',
  templateUrl: './trash-container.component.html',
  styleUrls: ['./trash-container.component.scss']
})
export class TrashContainerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
