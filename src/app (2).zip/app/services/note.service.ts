import { Injectable } from '@angular/core';
import { HttpService } from './http.service';


@Injectable({
  providedIn: 'root'
})
export class NoteService {

  constructor( public httpService:HttpService) { }
  getAllNotes(){
    return this.httpService.fetchNotes("Notes/GetAllNotes")
  }

  getTrashNotes(){
    return this.httpService.fetchNotes("Notes/IsTrash")
  }
  
  getArchiveNotes(){
    return this.httpService.fetchNotes("Notes/IsArchive")
  }
  createNotes(noteObj:object,headers:any){
    console.log("before token ", headers)
    return this.httpService.addNotes("Notes/AddNote",noteObj,headers)
   
  }

}
