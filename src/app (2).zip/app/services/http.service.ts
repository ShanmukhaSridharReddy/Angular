import { Injectable } from '@angular/core';
import { HttpClient,HttpParams,HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
interface noteObj {
  title:string,
  description:string,
  IsArchive:boolean
}

@Injectable({
  providedIn: 'root'
})
export class HttpService {

  private baseUrl ="https://localhost:44320/api/"
  // private queryParams = new HttpParams().set("access_token", localStorage.getItem('accessToken') || "")
  private authHeader = new HttpHeaders({
    'Accept': "application/json",
    'Authorization': localStorage.getItem('token') ||''
  })
  getNoteQueryParams: any;

  constructor(private http: HttpClient) { }

  async loginSignupCall(endpoint: string, data: any): Promise<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
    });

    try {
      const res = await this.http.post(this.baseUrl + endpoint, data).toPromise()
      console.log(res);
      
      return res
    } catch (error) {
      return error
    }

  }

  
  async signup(userData: any): Promise<any> {
    try {
      const res = await this.http.post(this.baseUrl + 'Register', userData).toPromise();
      console.log(res);
      return res;
    } catch (error) {
      return error;
    }
  }
  fetchNotes(endpoint:string):Observable<any>{
    return this.http.get(this.baseUrl+endpoint,{
      headers:this.authHeader
    }
      )
  }
  addNotes(endpoint:string, noteObj:object,headers:any):Observable<any>{
    
    console.log(headers);
    return this.http.post(this.baseUrl+endpoint,noteObj,{
      headers:this.authHeader
    })

    console.log(headers);
  }
}
