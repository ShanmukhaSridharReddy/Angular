import { Component, OnInit } from '@angular/core';
import { NoteService } from 'src/app/services/note.service';

interface noteObj {
  title:string,
  description:string,
  IsArchive:boolean
}

@Component({
  selector: 'app-archive-container',
  templateUrl: './archive-container.component.html',
  styleUrls: ['./archive-container.component.scss']
})


export class ArchiveContainerComponent implements OnInit {
archiveNotesList:any[]=[]

  constructor( public noteService:NoteService) { }

  ngOnInit(): void {

    this.noteService.getAllNotes().subscribe(
      res=> {this.archiveNotesList=res.data.filter(
        (item:noteObj) => item.IsArchive===true)
        console.log(this.archiveNotesList)}
    )
    
  }

}
